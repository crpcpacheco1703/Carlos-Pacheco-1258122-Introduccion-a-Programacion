﻿Console.Write("Ingrese su nombre: ");
string nombre = Console.ReadLine();

Console.WriteLine("Hola Mundo");
Console.WriteLine("Soy " + nombre);

Console.Write("Hola Mundo");
Console.Write(" soy " + nombre);
Console.ReadKey();