﻿class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("==========Separador de Palabras únicas==========");
        Console.Write("Escriba la oración deseada: ");
        string word = Console.ReadLine().ToString();

        char[] delimeters = new char[] { ' ', '.', '!', '?', ',' };

        foreach (var a in word.Split(delimeters, StringSplitOptions.RemoveEmptyEntries))
        {
            Console.WriteLine(a);
        }
        Console.ReadLine();
    }
}