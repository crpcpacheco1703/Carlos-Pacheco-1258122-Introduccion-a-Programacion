﻿int opcion;
// Para las formulas de °C a °F y °F a °C utilize un formulario de un parcial de matematicas
Console.WriteLine("==========Convertidor de Grados Centigrados==========");
    do
    {
    Console.WriteLine("Si desea salir escriba 0");
        Console.Write("Si desea transformar °C a °F escriba 1, sino 2 para °F a °C: ");
        opcion = Convert.ToInt32(Console.ReadLine());

        switch (opcion)
        {
            case 0:
                Console.WriteLine("Adios");
                break;
            case 1:
                CaF();
                break;
            case 2:
                FaC();
                break;
            default:
                Console.WriteLine("Opcion no valida");
                break;
        }
    } while (opcion != 0);

    static void CaF()
    {
        Console.WriteLine("=====Convertidor de °C a °F=====");
        Console.Write("Ingrese la temperatura en °C (Solo numeros): ");
        int C;
        int FEnd;

        try
        {
            C = Convert.ToInt32(Console.ReadLine());
            FEnd = (9 / 5) * (C) + 32;
            Console.WriteLine(C + "°C es " + FEnd + "°F");
        }
        catch (FormatException exception)
        {
            Console.WriteLine("No es un dato aceptable");
            Console.WriteLine(exception.Message);
        }
    }

    static void FaC()
    {
        Console.WriteLine("=====Convertidor de °F a °C=====");
        Console.Write("Ingrese la temperatura °F (Solo numeros): ");
        int F;
        int CEnd;

        try
        {
            F = Convert.ToInt32(Console.ReadLine());
            CEnd = (5 / 9) * (F - 32);
            Console.WriteLine(F + "°F es " + CEnd + "°C");
        }
        catch (FormatException exception)
        {
            Console.WriteLine("No es un dato aceptable");
            Console.WriteLine(exception.Message);
        }
    }
