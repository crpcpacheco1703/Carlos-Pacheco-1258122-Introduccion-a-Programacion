﻿double ValorA;
double ValorB;

Console.WriteLine("========== Introduzca los valores ==========");
Console.Write("Ingrese el primer valor numerico: ");
ValorA = Convert.ToDouble(Console.ReadLine());

Console.Write("Ingrese el segundo valor numerico: ");
ValorB = Convert.ToDouble(Console.ReadLine());

if (ValorA > ValorB)
{
    Console.WriteLine(ValorA + " es mayor que " + ValorB);
}
else
{
    Console.WriteLine(ValorB + " es mayor que " + ValorA);
}

Console.ReadKey();