﻿int Nota;
Console.WriteLine("==========Convertidor de Ponderación==========");
Console.Write("Escriba la nota numérica: ");
Nota = Convert.ToInt32(Console.ReadLine());

if (0 <= Nota && Nota <= 49)
{
    Console.WriteLine("Su nota de " + Nota + " es de F");
}
if (50 <= Nota && Nota <= 59)
{
    Console.WriteLine("Su nota de " + Nota + " es de E");
}
if (60 <= Nota && Nota <= 69)
{
    Console.WriteLine("Su nota de " + Nota + " es de D");
}
if (70 <= Nota && Nota <= 79)
{
    Console.WriteLine("Su nota de " + Nota + " es de C");
}
if (80 <= Nota && Nota <= 89)
{
    Console.WriteLine("Su nota de " + Nota + " es de B");
}
if (90 <= Nota && Nota <= 100)
{
    Console.WriteLine("Su nota de " + Nota + " es de A");
}
