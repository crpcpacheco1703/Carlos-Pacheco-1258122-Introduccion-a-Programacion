﻿using _1258122_CRPC_EC3;

cMenu Menu = new cMenu();

Console.WriteLine("=========================================");
Console.WriteLine("====Bienvenido al Restaurante Virtual====");
Console.WriteLine("Para abrir el Menu del Dia presiona ENTER");
Console.WriteLine("=========================================");
Console.ReadKey();
Console.Clear();

Menu.TxtInicio();
Menu.Formula1();
Console.ReadKey();