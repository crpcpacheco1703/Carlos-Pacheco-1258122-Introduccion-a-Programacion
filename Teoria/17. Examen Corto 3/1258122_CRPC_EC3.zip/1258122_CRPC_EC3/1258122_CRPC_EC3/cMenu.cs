﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1258122_CRPC_EC3
{
    internal class cMenu
    {
        string uMenu;
        int p1 = 15, p2 = 7, p3 = 7, p4 = 9;
        string i1 = "Hamburguesa", i2 = "Bebida Gaseosa", i3 = "Porcion de Papas Fritas", i4 = "Pie Dulce de Queso";
        public void TxtInicio()
        {
            Console.WriteLine("===========================Menu del Dia===========================");
            Console.WriteLine("Aqui podrá ordenar lo que desea comprar");
            Console.WriteLine("Selecciona los Items disponibles de hoy:");
            Console.WriteLine("(Para seleccionar escriba el número del item seguido con una coma)");
            Console.WriteLine("Ej: 1, 2, 3");
            Console.WriteLine("==================================================================");
            Console.WriteLine("1. Hamburguesa..................Q15");
            Console.WriteLine("2. Bebida Gaseosa...............Q7");
            Console.WriteLine("3. Porcion de Papas Fritas......Q7");
            Console.WriteLine("4. Pie Dulce de Queso...........Q9");
            Console.Write("Escriba el número de los items que desea: ");
            uMenu = Console.ReadLine();
            Console.WriteLine("==================================================================");
        }

        public void Formula1()
        {
            if (uMenu == "1")
            {
                Console.WriteLine("El/Los item(s) que desea comprar es/son: " + i1);
                Console.WriteLine("El total a pagar por su orden es de Q" + p1);
            }
            if (uMenu == "2")
            {
                Console.WriteLine("El/Los item(s) que desea comprar es/son: " + i2);
                Console.WriteLine("El total a pagar por su orden es de Q" + p2);
            }
            if (uMenu == "3")
            {
                Console.WriteLine("El/Los item(s) que desea comprar es/son: " + i3);
                Console.WriteLine("El total a pagar por su orden es de Q" + p3);
            }
            if (uMenu == "4")
            {
                Console.WriteLine("El/Los item(s) que desea comprar es/son: " + i4);
                Console.WriteLine("El total a pagar por su orden es de Q" + p4);
            }
            if (uMenu.Contains("1")&& uMenu.Contains("2") && !uMenu.Contains("3") && !uMenu.Contains("4"))
            {
                int sum = p1 + p2;
                Console.WriteLine("El/Los item(s) que desea comprar es/son: " + i1 + ", " + i2);
                Console.WriteLine("El total a pagar por su orden es de Q" + sum);
            }
            if (uMenu.Contains("1") && uMenu.Contains("3") && !uMenu.Contains("2") && !uMenu.Contains("4"))
            {
                int sum = p1 + p3;
                Console.WriteLine("El/Los item(s) que desea comprar es/son: " + i1 + ", " + i3);
                Console.WriteLine("El total a pagar por su orden es de Q" + sum);
            }
            if (uMenu.Contains("1") && uMenu.Contains("4") && !uMenu.Contains("2") && !uMenu.Contains("3"))
            {
                int sum = p1 + p4;
                Console.WriteLine("El/Los item(s) que desea comprar es/son: " + i1 + ", " + i4);
                Console.WriteLine("El total a pagar por su orden es de Q" + sum);
            }
            if (uMenu.Contains("2") && uMenu.Contains("3") && !uMenu.Contains("1") && !uMenu.Contains("4"))
            {
                int sum = p2 + p3;
                Console.WriteLine("El/Los item(s) que desea comprar es/son: " + i2 + ", " + i3);
                Console.WriteLine("El total a pagar por su orden es de Q" + sum);
            }
            if (uMenu.Contains("2") && uMenu.Contains("4") && !uMenu.Contains("3") && !uMenu.Contains("1"))
            {
                int sum = p2 + p4;
                Console.WriteLine("El/Los item(s) que desea comprar es/son: " + i2 + ", " + i4);
                Console.WriteLine("El total a pagar por su orden es de Q" + sum);
            }
            if (uMenu.Contains("3") && uMenu.Contains("4") && !uMenu.Contains("1") && !uMenu.Contains("2"))
            {
                int sum = p3 + p4;
                Console.WriteLine("El/Los item(s) que desea comprar es/son: " + i3 + ", " + i4);
                Console.WriteLine("El total a pagar por su orden es de Q" + sum);
            }
            if (uMenu.Contains("3") && uMenu.Contains("4") && uMenu.Contains("1") && uMenu.Contains("2"))
            {
                int sum = p3 + p4 + p2 + p1;
                Console.WriteLine("El/Los item(s) que desea comprar es/son: " + i1 + ", " + i2 + ", " + i3 + ", " + i4);
                Console.WriteLine("El total a pagar por su orden es de Q" + sum);
            }
            if (uMenu.Contains("1") && uMenu.Contains("2") && uMenu.Contains("3") && !uMenu.Contains("4"))
            {
                int sum = p1 + p2 + p3;
                Console.WriteLine("El/Los item(s) que desea comprar es/son: " + i1 + ", " + i2 + ", " + i3);
                Console.WriteLine("El total a pagar por su orden es de Q" + sum);
            }
            if (uMenu.Contains("1") && uMenu.Contains("2") && uMenu.Contains("4") && !uMenu.Contains("3"))
            {
                int sum = p1 + p2 + p4;
                Console.WriteLine("El/Los item(s) que desea comprar es/son: " + i1 + ", " + i2 + ", " + i4);
                Console.WriteLine("El total a pagar por su orden es de Q" + sum);
            }
            if (uMenu.Contains("1") && uMenu.Contains("4") && uMenu.Contains("3") && !uMenu.Contains("2"))
            {
                int sum = p1 + p4 + p3;
                Console.WriteLine("El/Los item(s) que desea comprar es/son: " + i1 + ", " + i3 + ", " + 43);
                Console.WriteLine("El total a pagar por su orden es de Q" + sum);
            }
            if (uMenu.Contains("4") && uMenu.Contains("2") && uMenu.Contains("3") && !uMenu.Contains("1"))
            {
                int sum = p4 + p2 + p3;
                Console.WriteLine("El/Los item(s) que desea comprar es/son: " + i2 + ", " + i3 + ", " + i4);
                Console.WriteLine("El total a pagar por su orden es de Q" + sum);
            }
            if (!uMenu.Contains("4") && !uMenu.Contains("2") && !uMenu.Contains("3") && !uMenu.Contains("1"))
            {
                Console.WriteLine("Opcion Invalida");
            }
        }
    }
}
