﻿/* Enunciado:
 * - Crear un programa que evalue edad de una persona y sepa si
 * - Si es menor de 10 años su entrada es gratis
 * - Si es mayor de 10 y menor de 15 su entrada vale Q. 15.00
 * - Si es mayor de 15 y menor de 21 su entrada vale Q. 25.00
 * - Si es mayor de 21 su entrada vale Q. 35.00
 * - Si es de la tercera edad entra gratis
 * - Si es menor de 10 años solo puede ver PG13
 * - Si es mayor de 10 y menor de 15 puede ver PG13 y puede ver PG15 si esta con un adulto
 * - Si es mayor de 15 puede ver PG15
 * - Si es mayor de 21 puede ver todas
 * - Si es de la tercera edad puede ver todas
 */

//Variables: edad, precio, clasificacion

int _edad, _precio;
string _clasificacion = "";
string _adulto = "";

Console.WriteLine("========== Bienvenido al Cine ==========");
Console.WriteLine("Ingrese edad:");
_edad = Convert.ToInt32(Console.ReadLine());

if (_edad <10)
{
    Console.WriteLine("El costo de la entrada es Q. 0.00");
}
else
{
    if (_edad >=10 && _edad <15)
    {
        Console.WriteLine("Estas acompañado de un adulto? (Si/No)");
        _adulto = Console.ReadLine().ToString();

        if (_adulto.ToLower() == "si")
        {
            _clasificacion = "PG15";
        }
        else
        {
            _clasificacion = "PG13";
        }
        Console.WriteLine("El costo de entrada es Q. 15.00 y la clasificacion es " + _clasificacion);
    }
}
if (_edad >= 15 && _edad < 21)
{
    Console.WriteLine("El costo de la entrada es Q. 25.00 y la clasificacion es PG15 y PG13");
}
if (_edad >=21 && _edad < 60)
{
    Console.WriteLine("El costo de la entrada es Q. 35.00 y puede ver todas las clasificaciones");
}
if (_edad >= 60)
{
    Console.WriteLine("La entrada es gratis y puede ver todas las clasificaciones");
}
Console.WriteLine("========== Pase a pagar en Taquilla ==========");