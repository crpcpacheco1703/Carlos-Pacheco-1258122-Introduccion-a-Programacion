﻿//Declaracion de variables
double r, pi, h;
double area;
double generatriz;
double areaCono = 0;

//Asignar valores
pi = 3.14;
r = 0;
h = 0;

//Solicitando al usuario ingreso de valores
Console.WriteLine("Ingrese un valor para el radio con decimales: ");
solicitarDatos();//LLamado a un procedimiento
double resultado = calculoArea(r);

//Solicitando al usuario ingreso de valores
Console.WriteLine("Ingrese un valor para la altura con decimales: ");
solicitarDatos();//LLamado a un procedimiento
double altura = calculoAltura(h);

double resultadoCono = calculoAreaCono(areaCono);

Console.WriteLine("El valor del area es: " + area.ToString());
Console.WriteLine("El valor del area del cono es: " + areaCono.ToString());
//Metodos = se dividen en funciones y procedimientos

//Declarar procedimientos
void solicitarDatos() {
    r = Convert.ToDouble(Console.ReadLine());
}

//Declarar funciones
double calculoArea(double radio) {
    //Calculo de area = pi*r^2
    area = pi * Math.Pow(r, 2);
    return area;
}

//Declarar funciones
double calculoAltura(double altura) {
    //Calculo de area de generatriz = g^2 = h^2 + r^2
    generatriz = Math.Sqrt(Math.Pow(h, 2) + Math.Pow(r, 2));
    return generatriz;
}

//Declarar funciones
double calculoAreaCono(double Cono) {
    //Calculo de area del cono = pi * r *(r + generatriz)
    areaCono = pi * r *(r + generatriz);
    return areaCono;
}