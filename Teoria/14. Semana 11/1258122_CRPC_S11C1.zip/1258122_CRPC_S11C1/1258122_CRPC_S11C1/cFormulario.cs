﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1258122_CRPC_S11C1
{
    internal class cFormulario
    {
        string _nombreCompleto, _genero, _nacionalidad, _carrera;
        int _edad;

        //Constructor
        public cFormulario()
        {
            _nombreCompleto = "";
            _genero = "";
            _nacionalidad = "";
            _carrera = "";
            _edad = 0;
        }

        public string getNombreCompleto()
        {
            return _nombreCompleto;
        }

        public void setNombreCompleto(string nombreCompleto)
        {
            _nombreCompleto = nombreCompleto;
        }

        public string getgenero()
        {
            return _genero;
        }

        public void setgenero(string genero)
        {
            _genero = genero;
        }
        public string getnacionalidad()
        {
            return _nacionalidad;
        }

        public void setnacionalidad(string nacionalidad)
        {
            _nacionalidad = nacionalidad;
        }
        public string getcarrera()
        {
            return _carrera;
        }

        public void setcarrera(string carrera)
        {
            _carrera = carrera;
        }
        public int getedad()
        {
            return _edad;
        }

        public void setedad(int edad)
        {
            _edad = edad;
        }
    }
}
