﻿int[] _Vector;
int _ContarDatos = 0;
Console.Write("Ingrese cantidad: ");
_ContarDatos = int.Parse(Console.ReadLine());
_Vector = new int[_ContarDatos];

for (int i = 0; i < _ContarDatos; i++)
{
    _Vector[i] = int.Parse(Console.ReadLine());
    if(_Vector[i] % 2 == 0)
    {
        Console.WriteLine("El número" + _Vector[i] + "Es par");
    }
    else
    {
        Console.WriteLine("El número" + _Vector[i] + "Es impar");
    }
}
Console.ReadKey();