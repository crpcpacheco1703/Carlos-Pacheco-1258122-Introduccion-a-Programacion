﻿/*
CODIGO ANTERIOR (METIDO EN TEXTO PARA TOMAR CONSTANCIA DE COMO LO HICE)
string Valor1, Valor2, Valor3, Valor4, Valor5, Valor6, Valor7, Valor8, Valor9, Valor10;

Console.Write("Ingrese la primera palabra: ");
Valor1 = Console.ReadLine().ToString();
Console.Write("Ingrese la segunda palabra: ");
Valor2 = Console.ReadLine().ToString();
Console.Write("Ingrese la tercera palabra: ");
Valor3 = Console.ReadLine().ToString();
Console.Write("Ingrese la cuarta palabra: ");
Valor4 = Console.ReadLine().ToString();
Console.Write("Ingrese la quinta palabra: ");
Valor5 = Console.ReadLine().ToString();
Console.Write("Ingrese la sexta palabra: ");
Valor6 = Console.ReadLine().ToString();
Console.Write("Ingrese la septima palabra: ");
Valor7 = Console.ReadLine().ToString();
Console.Write("Ingrese la octava palabra: ");
Valor8 = Console.ReadLine().ToString();
Console.Write("Ingrese la novena palabra: ");
Valor9 = Console.ReadLine().ToString();
Console.Write("Ingrese la decima palabra: ");
Valor10 = Console.ReadLine().ToString();
Console.WriteLine("A continuacion se le presentarán una lista de las palabras consideradas Molestas:");
Console.WriteLine("==================================================");
if (((Valor1.Contains("!!")) || (Valor1.Contains("??"))) && (Valor1.Any(char.IsUpper)))
{
    Console.WriteLine(Valor1 + " es Molesta");
}
if (((Valor2.Contains("!!")) || (Valor2.Contains("??"))) && (Valor2.Any(char.IsUpper)))
{
    Console.WriteLine(Valor2 + " es Molesta");
}
if (((Valor3.Contains("!!")) || (Valor3.Contains("??"))) && (Valor3.Any(char.IsUpper)))
{
    Console.WriteLine(Valor3 + " es Molesta");
}
if (((Valor4.Contains("!!")) || (Valor4.Contains("??"))) && (Valor4.Any(char.IsUpper)))
{
    Console.WriteLine(Valor4 + " es Molesta");
}
if (((Valor5.Contains("!!")) || (Valor5.Contains("??"))) && (Valor5.Any(char.IsUpper)))
{
    Console.WriteLine(Valor5 + " es Molesta");
}
if (((Valor6.Contains("!!")) || (Valor6.Contains("??"))) && (Valor6.Any(char.IsUpper)))
{
    Console.WriteLine(Valor6 + " es Molesta");
}
if (((Valor7.Contains("!!")) || (Valor7.Contains("??"))) && (Valor7.Any(char.IsUpper)))
{
    Console.WriteLine(Valor7 + " es Molesta");
}
if (((Valor8.Contains("!!")) || (Valor8.Contains("??"))) && (Valor8.Any(char.IsUpper)))
{
    Console.WriteLine(Valor8 + " es Molesta");
}
if (((Valor9.Contains("!!")) || (Valor9.Contains("??"))) && (Valor9.Any(char.IsUpper)))
{
    Console.WriteLine(Valor9 + " es Molesta");
}
if (((Valor10.Contains("!!")) || (Valor10.Contains("??"))) && (Valor10.Any(char.IsUpper)))
{
    Console.WriteLine(Valor10 + " es Molesta");
}
Console.ReadKey();
*/

using System;

class Program
{
    static void Main()
    {
        Console.Clear();
        string[] aPalabras = {"HOLA", "Casa", "carro", "LAPIZ", "uno", "dos", "tres", "ocho", "nueve", "diez"};

        for (int i=0; i<10; i++)
        {
            Console.WriteLine("Validando mayusculas.. " + aPalabras[i]);
            if (aPalabras[i].ToUpper() == aPalabras[i])
            {
                Console.WriteLine("La palabra: " + aPalabras[i] + " es mayuscula");
            }
        }
    }
}